"""Fact Graph Layer.

In-memory knowledge graph that connects:
  Organization -> Fact Types -> Normalized Values -> Evidence Source URLs & Snippets.
Identifies multi-page factual discrepancies with high confidence.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from src.inspection.url import extract_locale_prefix
from .fact_extractor import ExtractedFact
from .fact_normalizer import NormalizedFact


@dataclass
class FactEvidence:
    url: str
    raw_value: str
    context_snippet: str
    confidence: float


@dataclass
class FactCluster:
    fact_type: str
    normalized_value: NormalizedFact
    evidence_list: List[FactEvidence] = field(default_factory=list)


@dataclass
class FactConflict:
    fact_type: str
    cluster_a: FactCluster
    cluster_b: FactCluster
    confidence: float

    @property
    def affected_urls(self) -> List[str]:
        urls = {e.url for e in self.cluster_a.evidence_list} | {e.url for e in self.cluster_b.evidence_list}
        return sorted(list(urls))


class FactGraph:
    """Graph structure managing facts across all pages of a site snapshot."""

    def __init__(self, site: str):
        self.site = site
        # fact_type -> list of FactCluster
        self._clusters: Dict[str, List[FactCluster]] = {}

    def add_fact(self, fact: ExtractedFact) -> None:
        clusters = self._clusters.setdefault(fact.fact_type, [])
        evidence = FactEvidence(
            url=fact.source_url,
            raw_value=fact.raw_value,
            context_snippet=fact.context_snippet,
            confidence=fact.confidence,
        )

        # Check if fact matches an existing cluster in this fact_type
        matched = False
        for cluster in clusters:
            if self._facts_match_cluster(cluster.normalized_value, fact.normalized):
                # Merges into cluster (they agree)
                cluster.evidence_list.append(evidence)
                matched = True
                break

        if not matched:
            # Create new cluster
            new_cluster = FactCluster(
                fact_type=fact.fact_type,
                normalized_value=fact.normalized,
                evidence_list=[evidence],
            )
            clusters.append(new_cluster)

    @staticmethod
    def _facts_match_cluster(cluster_val: NormalizedFact, fact_val: NormalizedFact) -> bool:
        """Determines if a newly extracted fact belongs to an existing value cluster."""
        if cluster_val.fact_type == "price":
            if cluster_val.currency != fact_val.currency:
                return False
            if cluster_val.numeric_value is not None and fact_val.numeric_value is not None:
                if abs(cluster_val.numeric_value - fact_val.numeric_value) > 0.01:
                    return False
            if cluster_val.fee_category != fact_val.fee_category:
                return False
            return True
        return not cluster_val.is_conflict(fact_val)

    @staticmethod
    def _is_multi_tier_or_plan_option(ca: FactCluster, cb: FactCluster) -> bool:
        """Determines if two price clusters represent legitimate multi-tier plans or donation options."""
        snippets_a = " ".join(e.context_snippet.lower() for e in ca.evidence_list)
        snippets_b = " ".join(e.context_snippet.lower() for e in cb.evidence_list)
        all_snippets = f"{snippets_a} {snippets_b}"

        # 1. Check for donation option groups (e.g. Wikimedia donation buttons)
        if any(w in all_snippets for w in ("donate", "donation", "please select an amount", "any amount helps", "once monthly yearly")):
            return True

        # 2. Check for differing billing frequencies (annual vs monthly)
        has_annual_a = any(w in snippets_a for w in ("annual", "yearly", "year", "per year", "/year", "/yr", "total"))
        has_monthly_a = any(w in snippets_a for w in ("monthly", "month", "per month", "/month", "/mo"))
        has_annual_b = any(w in snippets_b for w in ("annual", "yearly", "year", "per year", "/year", "/yr", "total"))
        has_monthly_b = any(w in snippets_b for w in ("monthly", "month", "per month", "/month", "/mo"))

        if (has_annual_a and not has_monthly_a and has_monthly_b and not has_annual_b) or \
           (has_monthly_a and not has_annual_a and has_annual_b and not has_monthly_b):
            return True

        # 3. Check for distinct named plan tiers
        tiers = ["starter", "basic", "pro", "professional", "enterprise", "team", "business", "individual", "personal", "family", "student", "standard", "premium", "max"]
        tier_a = [t for t in tiers if t in snippets_a]
        tier_b = [t for t in tiers if t in snippets_b]
        if tier_a and tier_b and set(tier_a) != set(tier_b):
            return True

        return False

    @staticmethod
    def _is_distinct_fee_category(ca: FactCluster, cb: FactCluster) -> bool:
        """Determines if two price clusters represent distinct types of fees or services."""
        # 1. Compare normalized fee categories
        cat_a = ca.normalized_value.fee_category
        cat_b = cb.normalized_value.fee_category
        if cat_a and cat_b and cat_a != cat_b:
            return True

        # 2. Inspect evidence context snippets for distinct fee descriptors
        snippets_a = " ".join(e.context_snippet.lower() for e in ca.evidence_list)
        snippets_b = " ".join(e.context_snippet.lower() for e in cb.evidence_list)

        fee_descriptors = {
            "dispute": ("dispute", "chargeback", "inquiry", "resolution", "compelling evidence"),
            "token": ("token", "tokens", "tokenization", "card saving", "vault", "card token"),
            "step": ("step", "steps", "workflow", "workflows"),
            "mdr": ("mdr", "interchange", "per transaction", "transaction fee", "cap"),
            "setup": ("setup", "onboarding", "installation"),
            "refund": ("refund", "reversal"),
            "payout": ("payout", "withdrawal", "transfer fee"),
            "bank_transfer": ("wire", "ach", "direct debit", "sepa"),
        }

        found_cats_a = {cat for cat, words in fee_descriptors.items() if any(w in snippets_a for w in words)}
        found_cats_b = {cat for cat, words in fee_descriptors.items() if any(w in snippets_b for w in words)}

        if found_cats_a and found_cats_b and found_cats_a.isdisjoint(found_cats_b):
            return True

        # If one has a specific fee category (e.g. dispute/token/mdr) and the other has none or plan
        if (found_cats_a and not found_cats_b and any(w in snippets_b for w in ("plan", "subscription", "starts at", "pricing:"))) or \
           (found_cats_b and not found_cats_a and any(w in snippets_a for w in ("plan", "subscription", "starts at", "pricing:"))):
            return True

        return False

    @staticmethod
    def _is_distinct_product_or_subject_metric(ca: FactCluster, cb: FactCluster) -> bool:
        """Determines if two metric clusters represent distinct products, features, or metric units."""
        val_a = ca.normalized_value.canonical_value.lower()
        val_b = cb.normalized_value.canonical_value.lower()

        # 1. If normalized metric units differ (e.g. 'users' vs 'countries' vs 'enterprises'), not a conflict
        noun_a = val_a.split()[-1] if val_a.split() else ""
        noun_b = val_b.split()[-1] if val_b.split() else ""
        if noun_a and noun_b and noun_a != noun_b:
            return True

        # 2. Check if context snippets reference distinct named products or models
        snippets_a = " ".join(e.context_snippet for e in ca.evidence_list)
        snippets_b = " ".join(e.context_snippet for e in cb.evidence_list)
        import re
        products_a = set(re.findall(r"\b[A-Z][a-zA-Z0-9]+(?:\s+[A-Z0-9][a-zA-Z0-9]+)+\b", snippets_a))
        products_b = set(re.findall(r"\b[A-Z][a-zA-Z0-9]+(?:\s+[A-Z0-9][a-zA-Z0-9]+)+\b", snippets_b))
        if products_a and products_b and products_a.isdisjoint(products_b):
            return True

        return False

    def detect_conflicts(self) -> List[FactConflict]:
        """Scans all fact types for multiple conflicting clusters across pages."""
        conflicts: List[FactConflict] = []

        for fact_type, clusters in self._clusters.items():
            if len(clusters) < 2:
                continue

            # Compare pairs of clusters
            for i in range(len(clusters)):
                for j in range(i + 1, len(clusters)):
                    ca = clusters[i]
                    cb = clusters[j]
                    if ca.normalized_value.is_conflict(cb.normalized_value):
                        # Ensure the conflicting evidence comes from distinct pages
                        urls_a = {e.url for e in ca.evidence_list}
                        urls_b = {e.url for e in cb.evidence_list}

                        # If all evidence for both clusters comes from the EXACT same page(s),
                        # this represents multiple selectable options on that page, not a cross-page contradiction.
                        distinct_pages_a = urls_a - urls_b
                        distinct_pages_b = urls_b - urls_a
                        if not distinct_pages_a and not distinct_pages_b:
                            continue

                        # For pricing facts: check if they represent multi-tier or billing period options
                        if fact_type == "price":
                            if self._is_multi_tier_or_plan_option(ca, cb):
                                continue
                            if self._is_distinct_fee_category(ca, cb):
                                continue

                        # For metric facts: check if they represent distinct products or metric units
                        if fact_type == "metric" and self._is_distinct_product_or_subject_metric(ca, cb):
                            continue

                        # For naturally regional facts (headquarters, phone, price):
                        # If conflicting clusters come exclusively from distinct, non-overlapping regional locales,
                        # this represents legitimate regional variations rather than an organizational contradiction.
                        if fact_type in ("headquarters", "location", "address", "phone", "price"):
                            locales_a = {extract_locale_prefix(u) for u in urls_a}
                            locales_b = {extract_locale_prefix(u) for u in urls_b}
                            if (
                                locales_a
                                and locales_b
                                and None not in locales_a
                                and None not in locales_b
                                and locales_a.isdisjoint(locales_b)
                            ):
                                continue

                        # Compute joint confidence
                        max_conf_a = max(e.confidence for e in ca.evidence_list)
                        max_conf_b = max(e.confidence for e in cb.evidence_list)
                        joint_conf = round(min(max_conf_a, max_conf_b) * 0.95, 2)

                        conflicts.append(
                            FactConflict(
                                fact_type=fact_type,
                                cluster_a=ca,
                                cluster_b=cb,
                                confidence=joint_conf,
                            )
                        )

        return conflicts

    def get_consensus_facts(self) -> Dict[str, str]:
        """Returns fact types that have single undisputed consensus values."""
        consensus: Dict[str, str] = {}
        for fact_type, clusters in self._clusters.items():
            if len(clusters) == 1:
                consensus[fact_type] = clusters[0].normalized_value.canonical_value
        return consensus

    def get_summary(self) -> Dict[str, Any]:
        return {
            "total_fact_types": len(self._clusters),
            "fact_types": list(self._clusters.keys()),
            "total_facts_recorded": sum(
                len(c.evidence_list) for clist in self._clusters.values() for c in clist
            ),
        }
